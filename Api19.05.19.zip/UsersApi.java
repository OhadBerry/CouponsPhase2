package com.Ohad.Phase2.api;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Ohad.Phase2.beans.User;
import com.Ohad.Phase2.logic.UsersController;

@RestController
@RequestMapping("/Users")
public class UsersApi {

	@Autowired
	private UsersController usersController;

	/*
	@PostMapping
	public ClientType login(@RequestBody LoginData loginData) throws Exception {
		return this.usersController.login(loginData.getUserName(), loginData.getPassword());
	}
	 */
	
	@PostMapping
	public void createUser(@RequestBody User user) throws Exception {
		this.usersController.createUser(user);
		System.out.println("createUser " + user);
	}

	@PutMapping
	public void updateUser(@RequestBody User user) throws Exception {
		this.usersController.updateUser(user);
		System.out.println("updateUser " + user);
	}

	@DeleteMapping("/{userID}")
	public void deleteUserByID(@PathVariable("userID") long userID) throws Exception {
		this.usersController.deleteUserbyID(userID);
		System.out.println("deleteUserByID " + userID);
	}

	@GetMapping("/{userID}")
	public User getOneUserByID(@PathVariable("userID") long userID) throws Exception {
		System.out.println("getOneUserByID " + userID);
		return this.usersController.getUserbyID(userID);
	}

	/*
	@GetMapping("/allUsers")
	public List<User> getAllUsers() throws Exception {
		System.out.println("getAllUsers");
		return this.usersController.getAllUsers();
	}
	*/
}
