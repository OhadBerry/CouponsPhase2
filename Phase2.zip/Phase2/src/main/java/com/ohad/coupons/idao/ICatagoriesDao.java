package com.ohad.coupons.idao;

public interface ICatagoriesDao {

}
