package com.ohad.coupons.tests;

import dao.PurchasesDao;

public class TestPurchasesDao {
	public static void AllTests() throws Exception {
	System.out.println("Testing PurchasesDao");
	
	PurchasesDao myPurchasesDao = new PurchasesDao();
//	System.out.println("Customer id is: "+customer_id+" Coupon Id is: "+couponId);
//	Purchase purchase = new Purchase(customer_id,couponId);
	
//	myPurchasesDao.createCouponPurchase(purchase);
//	System.out.println(myPurchasesDao.isCouponPurchaseExists(purchase.getCustomer_id(),purchase.getCoupon_id()));
//	myPurchasesDao.deleteCouponPurchase(purchase.getCustomer_id(),purchase.getCoupon_id());
	}

}
