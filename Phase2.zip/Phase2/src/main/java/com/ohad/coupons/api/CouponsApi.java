package com.ohad.coupons.api;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ohad.coupons.beans.Coupon;
import com.ohad.coupons.enums.CouponType;
import com.ohad.coupons.logic.CouponsController;




@RestController
@RequestMapping("/coupons")
public class CouponsApi {
	
	@Autowired
	private CouponsController couponsController; 
	
	@PostMapping
	public void createCoupon(@RequestBody beans.Coupon coupon) throws Exception {
		couponsController.createCoupon(coupon);
	}
	
	
	
	@PutMapping
	public void updateCoupon(@RequestBody beans.Coupon coupon) throws Exception {
		couponsController.updateCoupon(coupon);
	}
	
	@GetMapping("/{couponId}")
	public Coupon getCoupon(@PathVariable("couponId") long id) {
		Coupon coupon = new Coupon(12, "Coca cola", new Date(), new Date(), 100, CouponType.Food ,"It will work believe me", 33.4, ":-(", 1111);
		return coupon;
	}
	
	@DeleteMapping("/{couponId}")
	public void deleteCoupon(@PathVariable("couponId") long id) throws Exception {
		couponsController.deleteCouponByID(id);
	}
/*	
	@GetMapping("/byType")
	// @RequestParam = get the value from the query string
	public void getCouponByType(@RequestParam("type") CouponType couponType) {
		return couponsController.getCouponByType(couponType);
	}
	*/
	
}
