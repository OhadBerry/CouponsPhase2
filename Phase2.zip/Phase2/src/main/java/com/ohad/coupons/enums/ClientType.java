package com.ohad.coupons.enums;

public enum ClientType {
	Administrator,
	Company,
	Customer,
	UnknownUser;

}
