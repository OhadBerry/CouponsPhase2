package com.ohad.coupons.enums;



public enum CouponType {
	Food ,
	Shopping,
	Restaurant,
	Hotel,
	Pool,
	Amusement_Park;
	
	public static final CouponType values[] = values();

	public static CouponType values(long j) {
		return values[(int) j];
	}

}
