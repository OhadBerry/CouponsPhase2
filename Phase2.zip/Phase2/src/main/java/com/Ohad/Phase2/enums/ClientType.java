package com.Ohad.Phase2.enums;

public enum ClientType {
	Administrator,
	Company,
	Customer,
	UnknownUser;

}
